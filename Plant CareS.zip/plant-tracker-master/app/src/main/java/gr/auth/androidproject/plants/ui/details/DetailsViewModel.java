package gr.auth.androidproject.plants.ui.details;

import androidx.lifecycle.ViewModel;

public class DetailsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}