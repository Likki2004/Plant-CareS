package gr.auth.androidproject.plants.ui.about;

import androidx.lifecycle.ViewModel;

public class AboutViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}